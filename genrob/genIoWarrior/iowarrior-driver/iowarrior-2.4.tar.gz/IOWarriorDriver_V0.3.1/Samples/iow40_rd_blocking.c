/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */


#include <stdlib.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <asm/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/hiddev.h>
#include <time.h>
#include <linux/input.h>

#include <linux/ioctl.h>
#include "iowarrior.h"


int main(int argc, char **argv)
{
	int fd1 = -1;


	if(( fd1 = open( "/dev/usb/iowarrior0", O_RDWR )) < 0 )
	{
		perror( "iowarrior0 open" );
		exit( 1 );
	}

	if( ioctl( fd1, IOW_SET_INTERVAL, 0 ))
	{
		perror( "evdev ioctl" );
		goto end;
	}


	// IO-Warrior 40 sends four bytes and time stamp on interface 0
	unsigned char value[5];

	int retval = read( fd1, value, 5 );
	if( retval == -1 )
	{
		perror( "evdev read" );
		goto end;
	}
	// print timestamp first, then the value
	printf ("%02x - %08lx\n", value[4], *((long *)value ));

	retval = read( fd1, value, 5 );
	if( retval == -1 )
	{
		perror( "evdev read" );
		goto end;
	}
	// print timestamp first, then the value
	printf ("%02x - %08lx\n", value[4], *((long *)value ));

end:
	close( fd1 );
	exit( 0 );
}
