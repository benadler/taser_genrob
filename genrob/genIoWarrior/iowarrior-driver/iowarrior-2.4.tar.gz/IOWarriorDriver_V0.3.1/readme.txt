Installing the IO-Warrior driver on Linux 2.4.x

1. Preparations

1.1 Patching module "hid.o"
To prevent the standard HID input driver from grabbing the IO-Warrior it is necessary to
add an entry to the blacklist in the "hid-code.c" file. This file is part of the "hid.o"
module. You can either copy the enclosed module to your system or build a new module with
the source files provided.
Typically the path for the folder containing the module on your system is:
	'/lib/modules/<version>/kernel/drivers/usb/'
In any case it is advisable to keep a copy of the old module. Though the old module has
to be moved away from the drivers folder or it will cause conflict over which module
is being loaded.

1.2 Generating device nodes
Accessing IO-Warrior is done via the "/dev" directory. Appropriate entries have to be
generated. The enclosed shell script "iowarrior_load" does automatically generate the
necessary entries. The script has to be executed with root permissions. The script will
generate device nodes "/dev/usb/iowarrior<X>", X ranges from 0 to 15, this allows you to
control up to 8 IO-Warriors (see section 3)


2. Installing the driver

To temporarily run the driver it is sufficient to execute 'insmod iowarrior.o'. Removing
the driver is done with 'rmmod iowarrior'.
To automatically activate the driver on every system start copy the file "iowarrior.o" to
the same folder as the module "hid.o" and add an "modprobe iowarrior" entry to the file
'/etc/init.d/boot.local'. Before this will work you will have to once issue the command
'depmod' to update the 'modules.*' files in the '/lib'modules/<Version>/' directory.
The driver is enclosed in source code (iowarrior.c).


3. Accessing IO-Warrior

Each interface of the IO-Warrior uses one device node. For IOW40 and IOW24 this means
they are using two nodes for each chip, the first one for the simple I/O and the second
one to access the special mode functions.
The driver has a buffer for 16 data packets per interface. If the 17th packet arrives
before any packet has been read the oldest packet will be discarded. To allow detecting
a buffer overflow each packet does get a sequence number. Sequence numbers are running
from 0 to 255 and wrap, for each packet the sequence number is incremented by 1.
The sequence number is available only for access via the read function, ioctl does not
provide the sequence number. The data buffer has to add a byte to the data size to hold
the sequence number.

For further details please refer to the sample code.
